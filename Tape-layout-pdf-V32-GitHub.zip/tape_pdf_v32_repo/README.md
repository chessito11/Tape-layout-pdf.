# ATLAS Tape Layout PDF Lab — V32

V32 adds a visible original-PDF page underlay while keeping extracted vector geometry for snapping/layout.

Highlights:
- Original PDF sheet is rendered in the ATLAS viewer.
- Vector paths remain separate snap geometry.
- Optional extracted text overlay.
- Multi-page selector remains available.
- Safari-safe PDF text extraction from V31 is retained.
- Rendered page preview is saved locally with the ATLAS project slot.

Upload `index.html` and `manifest.webmanifest` to the repository root.
