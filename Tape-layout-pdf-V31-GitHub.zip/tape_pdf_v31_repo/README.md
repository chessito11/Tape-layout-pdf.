# ATLAS Tape Layout PDF Lab — V31

Safari/iPad compatibility fix for PDF text extraction.

- Keeps V29/V30 vector PDF geometry import.
- Keeps PDF titles, labels, dimensions and notes as a display-only text layer.
- Replaces PDF.js `getTextContent()` with `streamTextContent().getReader()` so Safari/iPad does not crash on missing `ReadableStream[Symbol.asyncIterator]`.
- PDF text remains non-snappable; ATLAS snapping/layout uses vector geometry only.
