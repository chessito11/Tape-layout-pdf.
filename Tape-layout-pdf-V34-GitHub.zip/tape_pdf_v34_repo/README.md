# ATLAS Tape Layout V34 — PDF to DXF Core

This branch intentionally returns to the proven V29 PDF vector-conversion path.

- Open vector PDF or DXF
- Select PDF page
- Convert PDF vector paths into ATLAS line geometry
- Calibrate with CAL 1 / CAL 2
- Use A/B, X1–X5 and SHIFT ORTHO
- Save up to five local projects
- Export the converted geometry as an ASCII DXF (feet)

The experimental full-PDF-page rendering/text-layer path is intentionally not included here because it was unreliable on iPad Safari.
