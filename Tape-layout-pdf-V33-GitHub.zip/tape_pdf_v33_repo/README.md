# ATLAS Tape Layout PDF Lab — V33

V33 keeps the V32 PDF page underlay and adds a Safari/iPadOS ReadableStream compatibility layer before PDF.js loads.

This fixes the Safari error:
`undefined is not a function (near '...value of readableStream...')`

The compatibility layer adds `ReadableStream[Symbol.asyncIterator]` using the browser-supported `getReader()` API. V32 features remain: full PDF page underlay, extracted geometry for snapping/layout, PDF text overlay, five local project slots, A/B anchors, X1–X5, SHIFT ORTHO, theme toggle, and calibration.
